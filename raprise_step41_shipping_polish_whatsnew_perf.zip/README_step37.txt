RapRise - Step 37 (Content Pass)

Cosa cambia:
- Tutte le schermate ora sono "piene" e coerenti (niente pagine vuote):
  - Home: KPI + azioni rapide + evento settimana + ultime uscite
  - Studio: Song Lab (titolo/lyrics/hook), bozze, catalogo
  - Social: KPI + feed + post/collab
  - Season: quest + progress pass + milestone
  - Shop: wallet + daily deals + free reward
  - Notes: header e compatibilita con Step34

Build:
- CSS: app.18959a8c10.css
- JS:  app.2e052eee24.js
- SRI aggiornato in index.html
- build.json e sw.js allineati ai nuovi asset

Uso:
- Apri QA (Ctrl+Shift+D) e lancia Regression Suite dopo il deploy.

Deploy:
- Carica tutti i file (incl. icons/ e splash/) nella root di GitHub Pages.
