RapRise - Step 38 (Visual upgrade pass)

Aggiunte:
- Transizioni tra schermate (fade/slide) con classe .rr-active
- Micro-animazioni su card e pulsanti (hover/press) senza impatto su mobile
- Skeleton loader per Notes (percezione velocita)
- Motion gating:
  - prefers-reduced-motion
  - Perf Mode (raprise_perf_mode_v1 = 1)

Build:
- CSS: app.221360cf0b.css
- JS:  app.b8b5caee06.js
- build.json e sw.js allineati
