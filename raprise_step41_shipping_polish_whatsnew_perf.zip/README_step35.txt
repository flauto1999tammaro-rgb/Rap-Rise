RapRise - Step 35 (Telemetry light + Diagnostica)

Aggiunte:
- Telemetry locale (senza server) con ring buffer eventi:
  - error, unhandledrejection, nav hashchange, click high-level
- Pulsanti nelle Impostazioni:
  - Copia Diagnostica (JSON completo)
  - Reset log
- Diagnostica include: build id, SW status, cache keys, perf marks, meta salvataggio e ultimi eventi.

Uso:
- Impostazioni (⚙️) -> Diagnostica -> Copia Diagnostica
- Incolla qui il JSON se serve debug.

Deploy:
- Nessun file aggiuntivo richiesto.
