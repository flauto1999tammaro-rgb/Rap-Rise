RapRise - Step 33 (iOS Splash Screens + About/Version)

Aggiunte:
- Splash screens iOS (apple-touch-startup-image) in /splash
- Sezione "Info & Versione" nelle Impostazioni:
  - Build id
  - Stato Service Worker
  - Numero cache raprise-
  - Controlla aggiornamenti
  - Disattiva offline (unregister SW + clear cache)

Deploy:
- Carica anche la cartella /splash oltre a /icons.
- iOS/Safari: l'effetto splash richiede Aggiungi a schermata Home.
