RapRise - Step 32 (Brand polish + In-game Settings Panel)

Aggiunte:
- Meta Apple PWA: apple-mobile-web-app-capable, status-bar-style, title
- Manifest arricchito: shortcuts e display_override
- Pannello Impostazioni in-game:
  - Perf Mode / Safe Mode toggle
  - Apri QA Console
  - Export salvataggio / ripristino backup / ricarica

Deploy:
- Carica tutto nella root, inclusa cartella icons/.
- I file hashati NON vanno rinominati.
